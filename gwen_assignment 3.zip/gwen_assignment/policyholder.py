class Policyholder:
    def __init__(self, name, policy_id):
        self.name = name
        self.policy_id = policy_id
        self.is_active = True

    def suspend(self):
        if self.is_active:
            self.is_active = False
            print(f"Policyholder {self.name} (ID: {self.policy_id}) has been suspended.")
        else:
            print(f"Policyholder {self.name} is already suspended.")

    def reactivate(self):
        if not self.is_active:
            self.is_active = True
            print(f"Policyholder {self.name} (ID: {self.policy_id}) has been reactivated.")
        else:
            print(f"Policyholder {self.name} is already active.")