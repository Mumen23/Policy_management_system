from policyholder import Policyholder
from product import Product
from payment import Payment

def main():
    # Create Products
    product1 = Product(101, "Health Insurance", 5000)
    product2 = Product(102, "Vehicle Insurance", 3000)

    # Create Policyholders
    policyholder1 = Policyholder("John Doe", 1)
    policyholder2 = Policyholder("Jane Smith", 2)

    # Process Payments
    payment1 = Payment(policyholder1, product1)
    payment2 = Payment(policyholder2, product2)

    # Demonstration
    payment1.process_payment()
    payment2.remind_payment()
    policyholder2.suspend()
    payment2.process_payment()
    policyholder2.reactivate()
    payment2.process_payment()

    # Update product pricing
    product1.update_price(5500)

if __name__ == "__main__":
    main()