class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price

    def update_price(self, new_price):
        self.price = new_price
        print(f"The price of {self.name} has been updated to {self.price}.")