class Payment:
    def __init__(self, policyholder, product):
        self.policyholder = policyholder
        self.product = product
        self.is_paid = False

    def process_payment(self):
        if self.policyholder.is_active:
            self.is_paid = True
            print(f"Payment for {self.product.name} by {self.policyholder.name} has been processed.")
        else:
            print(f"Payment failed. Policyholder {self.policyholder.name} is not active.")

    def remind_payment(self):
        if not self.is_paid:
            print(f"Reminder: {self.policyholder.name}, please pay for {self.product.name}.")
        else:
            print(f"Payment for {self.product.name} has already been made.")

    def apply_penalty(self):
        if not self.is_paid:
            print(f"Penalty applied to {self.policyholder.name} for overdue payment on {self.product.name}.")
        else:
            print(f"No penalty. Payment has already been made.")