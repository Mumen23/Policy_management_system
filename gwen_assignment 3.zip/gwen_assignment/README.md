# Policy Management System

This repository contains a Python-based implementation of a simple Policy Management System. It is designed to manage policyholders, their associated products, and the payment processes. Below is a detailed guide to understand and utilize the code.

## Features
- **Policyholder Management**
  - Suspend and reactivate policyholders.
- **Product Management**
  - Create products and update their pricing.
- **Payment Processing**
  - Process payments, send reminders, and apply penalties for overdue payments.

## File Structure

- **policyholder.py**: Contains the `Policyholder` class for managing policyholder operations (e.g., suspension and reactivation).
- **product.py**: Contains the `Product` class for managing product information and pricing.
- **payment.py**: Contains the `Payment` class for processing payments, reminders, and penalties.
- **main.py**: Demonstrates the interaction between policyholders, products, and payments. It serves as the entry point for the program.

## Dependencies
This project does not require any external libraries. It is implemented using core Python.

## How to Run
1. Clone the repository:
   ```bash
   git clone <repository_url>
   cd <repository_directory>
   ```

2. Run the `main.py` file:
   ```bash
   python main.py
   ```

## Usage
The `main.py` file demonstrates how to use the classes:
1. **Create Products**: Products are created with an ID, name, and price.
2. **Create Policyholders**: Policyholders are created with a name and unique policy ID.
3. **Process Payments**: Payments can be processed for active policyholders.
4. **Send Reminders**: Reminders are sent for unpaid products.
5. **Suspend/Reactivate Policyholders**: Policyholders can be suspended and reactivated as needed.
6. **Update Product Prices**: Product prices can be updated dynamically.

## Code Overview

### `Policyholder` Class
- **Attributes**:
  - `name`: Name of the policyholder.
  - `policy_id`: Unique identifier for the policyholder.
  - `is_active`: Status of the policyholder (active/inactive).
- **Methods**:
  - `suspend()`: Suspend the policyholder.
  - `reactivate()`: Reactivate the policyholder.

### `Product` Class
- **Attributes**:
  - `product_id`: Unique identifier for the product.
  - `name`: Name of the product.
  - `price`: Price of the product.
- **Methods**:
  - `update_price(new_price)`: Update the price of the product.

### `Payment` Class
- **Attributes**:
  - `policyholder`: Associated policyholder.
  - `product`: Associated product.
  - `is_paid`: Status of the payment (paid/unpaid).
- **Methods**:
  - `process_payment()`: Process payment if the policyholder is active.
  - `remind_payment()`: Send a payment reminder if payment is not made.
  - `apply_penalty()`: Apply a penalty for overdue payments.

## Example
Here is a sample interaction:
```python
# Create a product
product = Product(101, "Health Insurance", 5000)

# Create a policyholder
policyholder = Policyholder("John Doe", 1)

# Create a payment instance
payment = Payment(policyholder, product)

# Process the payment
payment.process_payment()

# Suspend the policyholder and attempt payment again
policyholder.suspend()
payment.process_payment()

# Reactivate the policyholder
policyholder.reactivate()
payment.process_payment()
```



